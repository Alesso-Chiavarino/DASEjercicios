package ar.edu.ubp.das.app.cliente;

import java.awt.Dimension;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.IOException;
import java.net.Socket;

import javax.swing.JFrame;
import javax.swing.WindowConstants;

public class ClienteChat {

    private PanelCliente panel;

    public static void main(String[] args) {
        new ClienteChat();
    }

    public ClienteChat() {
        try {
            JFrame v = new JFrame();
            panel = new PanelCliente(v.getContentPane());

            v.pack();
            v.setSize(new Dimension(500, 500));
            v.setVisible(true);
            v.setResizable(false);
            v.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
            v.addWindowListener( new WindowAdapter() {
                public void windowOpened(WindowEvent e ){
                    panel.textField.requestFocus();
                }
            });
            panel.socket = new Socket("localhost", 5557);

            new ControlCliente(panel);
        }
        catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
    }

}
