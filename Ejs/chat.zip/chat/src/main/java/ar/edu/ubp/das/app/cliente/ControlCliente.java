package ar.edu.ubp.das.app.cliente;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;

public class ControlCliente implements ActionListener, Runnable {

    private PanelCliente panel;
    private Cliente cliente;

    public ControlCliente(PanelCliente p) {
        try {
            panel = p;

            addActionListener(this);

            cliente = new Cliente();
            cliente.dataInput = new DataInputStream(panel.socket.getInputStream());
            cliente.dataOutput = new DataOutputStream(panel.socket.getOutputStream());

            Thread hilo = new Thread(this);
            hilo.start();
        }
        catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
    }

    public void actionPerformed(ActionEvent e) {
        try {
            cliente.dataOutput.writeUTF(getTexto());
        }
        catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
    }

    public void run() {
        try {
            while (true) {
                addTexto(cliente.dataInput.readUTF());
                addTexto("\n");
            }
        }
        catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
    }

    public void addActionListener(ActionListener accion) {
        panel.textField.addActionListener(accion);
        panel.boton.addActionListener(accion);
    }

    public void addTexto(String texto) {
        panel.textArea.append(texto);
    }

    public String getTexto() {
        String texto = panel.textField.getText();
        panel.textField.setText("");
        return texto;
    }

    public class Cliente {

        public DataInputStream dataInput;
        public DataOutputStream dataOutput;

    }

}
