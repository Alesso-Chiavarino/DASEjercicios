package ar.edu.ubp.das.app.cliente;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.FlowLayout;
import java.net.Socket;

import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class PanelCliente {

    JTextArea textArea;
    JTextField textField;
    JButton boton;
    Socket socket;

    public PanelCliente(Container contenedor) {
        contenedor.setLayout(new BorderLayout());
        textArea = new JTextArea();
        textArea.setEditable(false);
        textArea.setLineWrap(true);

        JScrollPane scroll = new JScrollPane(textArea);
        scroll.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);

        JPanel panel = new JPanel(new FlowLayout());
        textField = new JTextField(30);

        boton = new JButton("Enviar");

        panel.add(textField);
        panel.add(boton);

        contenedor.add(scroll, BorderLayout.CENTER);
        contenedor.add(panel, BorderLayout.SOUTH);
    }

}
