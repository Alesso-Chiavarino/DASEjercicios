package ar.edu.ubp.das.app.servidor;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

import javax.swing.DefaultListModel;
import javax.swing.event.ListDataEvent;
import javax.swing.event.ListDataListener;

public class ServidorChat {

    DefaultListModel<String> conversaciones;
    ServerSocket socketServidor;
    int clientes;

    public static void main(String[] args) {
        new ServidorChat();
    }

    public ServidorChat() {
        try {
            conversaciones = new DefaultListModel<String>();
            socketServidor = new ServerSocket(5557);
            System.out.println("Servidor iniciado...");
            while (true) {
                Socket cliente = socketServidor.accept();
                Thread hilo = new Thread(new HiloDeCliente(cliente));
                hilo.start();
            }
        }
        catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
    }

    public class HiloDeCliente implements Runnable, ListDataListener {

        Cliente cliente;

        public HiloDeCliente(Socket socket) {
            cliente = new Cliente();

            try {
                cliente.nomCliente = "USUARIO " + (++clientes);
                cliente.dataInput = new DataInputStream(socket.getInputStream());
                cliente.dataOutput = new DataOutputStream(socket.getOutputStream());
                ServidorChat.this.conversaciones.addListDataListener(this);
            }
            catch (IOException ex) {
                System.out.println(ex.getMessage());
            }
        }

        public void run() {
            try {
                while (true) {
                    String texto = cliente.nomCliente + ": " + cliente.dataInput.readUTF();
                    synchronized (ServidorChat.this.conversaciones) {
                        ServidorChat.this.conversaciones.addElement(texto);
                    }
                }
            }
            catch (IOException ex) {
                System.out.println(ex.getMessage());
            }
        }

        public void intervalAdded(ListDataEvent e) {
            try {
                cliente.dataOutput.writeUTF(String.valueOf(ServidorChat.this.conversaciones.getElementAt(e.getIndex0())));
            }
            catch (IOException ex) {
                System.out.println(ex.getMessage());
            }
        }

        public void intervalRemoved(ListDataEvent e) {
        }

        public void contentsChanged(ListDataEvent e) {
        }

        public class Cliente {

            public String nomCliente;
            public DataInputStream dataInput;
            public DataOutputStream dataOutput;

        }

    }

}
