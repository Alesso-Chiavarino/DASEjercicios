package ar.edu.ubp.das.app;

import java.util.Arrays;

public class Run {

    // NO CONSIDERAR PARA REFACTORIZAR
    public static void main(String[] args) {
        MisVentas mv = new MisVentas();

        Producto p1 = new Producto("PRODUCTO 1", 10, 5);
        Producto p2 = new Producto("PRODUCTO 2", 4, 30);

        Venta v1 = new Venta(Arrays.asList(p1, p2), "CLIENTE 1", "En línea");
        mv.agregarVenta(v1);

        Producto p3 = new Producto("PRODUCTO 3", 5, 5);
        Producto p4 = new Producto("PRODUCTO 4", 15, 2);

        Venta v2 = new Venta(Arrays.asList(p3, p4), "CLIENTE 2", "Minorista");
        mv.agregarVenta(v2);

        Producto p5 = new Producto("PRODUCTO 5", 25, 15);
        Producto p6 = new Producto("PRODUCTO 6", 4, 8);

        Venta v3 = new Venta(Arrays.asList(p5, p6), "CLIENTE 3", "Mayorista");
        mv.agregarVenta(v3);

        System.out.print(mv);
    }

}
