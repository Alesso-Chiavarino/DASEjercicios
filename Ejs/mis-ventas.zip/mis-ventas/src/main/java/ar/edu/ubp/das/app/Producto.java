package ar.edu.ubp.das.app;

public class Producto {

    public String nombre;
    public int cantidad;
    public double precio;

    public Producto(String nombre, int cantidad, double precio) {
        this.nombre = nombre;
        this.cantidad = cantidad;
        this.precio = precio;
    }

}
