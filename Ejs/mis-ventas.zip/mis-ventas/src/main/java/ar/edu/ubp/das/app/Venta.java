package ar.edu.ubp.das.app;

import java.util.List;

public class Venta {

    private List<Producto> productos;
    private String cliente;
    private String tipoVenta;

    public Venta(List<Producto> productos, String cliente, String tipoVenta) {
        this.productos = productos;
        this.cliente = cliente;
        this.tipoVenta = tipoVenta;
    }

    public List<Producto> getProductos() {
        return this.productos;
    }

    public String getCliente() {
        return cliente;
    }

    public String getTipoVenta() {
        return tipoVenta;
    }

    public double getDescuento() {
        double descuento = 0;
        if (tipoVenta.equals("En línea")) {
            descuento = 0.10;
        }
        else if (tipoVenta.equals("Minorista")) {
            descuento = 0.05;
        }
        else if (tipoVenta.equals("Mayorista")) {
            descuento = 0.15;
        }
        return descuento;
    }

    public double calcularEnvio() {
        double costoEnvio = 0;
        if (tipoVenta.equals("En línea")) {
            costoEnvio = 5.00;
        }
        else if (tipoVenta.equals("Minorista")) {
            costoEnvio = 0;
        }
        else if (tipoVenta.equals("Mayorista")) {
            costoEnvio = 20.00;
        }
        return costoEnvio;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("CLIENTE: ");
        sb.append(this.cliente);
        sb.append("\n");

        sb.append("TIPO DE VENTA: ");
        sb.append(this.tipoVenta);
        sb.append("\n");

        sb.append("DESCUENTO: ");
        sb.append(this.getDescuento());
        sb.append("\n");

        sb.append("COSTO DE ENVÍO: ");
        sb.append(this.calcularEnvio());
        sb.append("\n");

        sb.append("PRODUCTOS ADQUIRIDOS:\n");
        for(Producto p : this.productos) {
            sb.append(p.nombre);
            sb.append(" - Cantidad: ");
            sb.append(p.cantidad);
            sb.append(" - Precio: ");
            sb.append(p.precio);
            sb.append("\n");
        }
        return sb.toString();
    }

}

