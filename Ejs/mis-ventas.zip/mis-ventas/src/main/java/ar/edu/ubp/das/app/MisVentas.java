package ar.edu.ubp.das.app;

import java.util.ArrayList;
import java.util.List;

public class MisVentas {

    private List<Venta> ventas;

    public MisVentas() {
        ventas = new ArrayList<Venta>();
    }

    public void agregarVenta(Venta venta) {
        ventas.add(venta);
    }

    public double calcularTotalDeUnaVenta(Venta venta) {
        double total = 0;
        for (Producto producto : venta.getProductos()) {
            total += producto.cantidad * producto.precio;
        }

        double costoEnvio = 0;
        if (venta.getTipoVenta().equals("En línea")) {
            costoEnvio = 5.00;
        }
        else if (venta.getTipoVenta().equals("Minorista")) {
            costoEnvio = 0;
        }
        else if (venta.getTipoVenta().equals("Mayorista")) {
            costoEnvio = 20.00;
        }

        return (total - (total * venta.getDescuento())) + costoEnvio;
    }

    public double calcularTotalVentas() {
        double total = 0;
        for (Venta venta : ventas) {
            total += calcularTotalDeUnaVenta(venta);
        }
        return total;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("VENTAS ");
        for(Venta v : this.ventas) {
            sb.append("\n*******************************************\n");
            sb.append(v);
            sb.append("*******************************************\n");
            sb.append("TOTAL A PAGAR: ");
            sb.append(this.calcularTotalDeUnaVenta(v));
            sb.append("\n*******************************************\n");
        }
        sb.append("\nTOTAL DE VENTAS: ");
        sb.append(this.calcularTotalVentas());
        sb.append("\n*******************************************\n");
        return sb.toString();
    }

}

